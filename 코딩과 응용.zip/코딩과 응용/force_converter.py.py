def convert_force(force_kn):
    force_n = force_kn * 1000
    force_kgf = force_n / 9.81
    return force_n, force_kgf

def main():
    while True:
        try:
            force_kn = float(input("힘을 입력하세요 [kN]: "))
            break
        except ValueError:
            print("잘못된 입력입니다. 숫자를 입력하세요.")

    force_n, force_kgf = convert_force(force_kn)

    print(f"힘: {force_n:.2f} N")
    print(f"힘: {force_kgf:.2f} kgf")


if __name__ == "__main__":
    main()